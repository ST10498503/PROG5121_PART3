/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.finalpoequickchat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_Lab
 */
public class FinalPOEQuickChatIT {
    
    public FinalPOEQuickChatIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class FinalPOEQuickChat.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        FinalPOEQuickChat.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class FinalPOEQuickChat.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        FinalPOEQuickChat.registerUser();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class FinalPOEQuickChat.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        boolean expResult = false;
        boolean result = FinalPOEQuickChat.loginUser();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of runMainMenu method, of class FinalPOEQuickChat.
     */
    @Test
    public void testRunMainMenu() {
        System.out.println("runMainMenu");
        FinalPOEQuickChat.runMainMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sendMessages method, of class FinalPOEQuickChat.
     */
    @Test
    public void testSendMessages() {
        System.out.println("sendMessages");
        FinalPOEQuickChat.sendMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sendMessagesDialog method, of class FinalPOEQuickChat.
     */
    @Test
    public void testSendMessagesDialog() {
        System.out.println("sendMessagesDialog");
        FinalPOEQuickChat.sendMessagesDialog();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of openMessageManager method, of class FinalPOEQuickChat.
     */
    @Test
    public void testOpenMessageManager() {
        System.out.println("openMessageManager");
        FinalPOEQuickChat.openMessageManager();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of messageManagerMenu method, of class FinalPOEQuickChat.
     */
    @Test
    public void testMessageManagerMenu() {
        System.out.println("messageManagerMenu");
        FinalPOEQuickChat.messageManagerMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displaySendersAndRecipients method, of class FinalPOEQuickChat.
     */
    @Test
    public void testDisplaySendersAndRecipients() {
        System.out.println("displaySendersAndRecipients");
        FinalPOEQuickChat.displaySendersAndRecipients();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayLongestMessage method, of class FinalPOEQuickChat.
     */
    @Test
    public void testDisplayLongestMessage() {
        System.out.println("Where are you? You are late!, I have asked you to be on time.");
        FinalPOEQuickChat.displayLongestMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByMessageID method, of class FinalPOEQuickChat.
     */
    @Test
    public void testSearchByMessageID() {
        System.out.println("0838884567");
        System.out.println("It is dinner time!");
        String id = "";
        FinalPOEQuickChat.searchByMessageID(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByRecipient method, of class FinalPOEQuickChat.
     */
    @Test 
    public void testSearchByRecipient() {
        System.out.println("Where are you? You are late! I have asked you to be on time. Ok, I am leaving without you.");
        String recipientNumber = "+27838884567";
        FinalPOEQuickChat.searchByRecipient(recipientNumber);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        
    }

    /**
     * Test of deleteByMessageHash method, of class FinalPOEQuickChat.
     */
    @Test
    public void testDeleteByMessageHash() {
        System.out.println("deleteByMessageHash");
        String hash = "";
        FinalPOEQuickChat.deleteByMessageHash(hash);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        return;
    }

    /**
     * Test of displayReport method, of class FinalPOEQuickChat.
     */
    @Test
    public void testDisplayReport() {
        System.out.println("displayReport");
        FinalPOEQuickChat.displayReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateMessageID method, of class FinalPOEQuickChat.
     */
    @Test
    public void testGenerateMessageID() {
        System.out.println("generateMessageID");
        String expResult = "";
        String result = FinalPOEQuickChat.generateMessageID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        return;
    }

    /**
     * Test of generateMessageHash method, of class FinalPOEQuickChat.
     */
    @Test
    public void testGenerateMessageHash() {
        System.out.println("generateMessageHash");
        String id = "";
        int num = 0;
        String msg = "";
        String expResult = "";
        String result = FinalPOEQuickChat.generateMessageHash(id, num, msg);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayMessageDetails method, of class FinalPOEQuickChat.
     */
    @Test
    public void testDisplayMessageDetails() {
        System.out.println("displayMessageDetails");
        String id = "";
        String hash = "";
        String recipient = "";
        String message = "";
        FinalPOEQuickChat.displayMessageDetails(id, hash, recipient, message);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loadTestData method, of class FinalPOEQuickChat.
     */
    @Test
    public void testLoadTestData() {
        System.out.println("It is diner time!");
        FinalPOEQuickChat.loadTestData();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        
    }
    
}
