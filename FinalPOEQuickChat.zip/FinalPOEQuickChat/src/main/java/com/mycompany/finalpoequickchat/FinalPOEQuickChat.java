/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.finalpoequickchat;

/**
 *
 * @author RC_Student_Lab
 */
//This is used to store the lists and all the data that is related
import java.util.ArrayList; 
import java.util.Random;

//This shows the message dialogs
import javax.swing.JOptionPane;

//This import is used to store characters, data(text) to a file. 
import java.io.FileWriter;

//This is the base exception for input/output operations that go wrong(file not found, network error or disk full) 
import java.io.IOException;

//To display the local date and time
import java.util.Date;
import java.text.SimpleDateFormat;

//This dialogs the components like frames and buttons
import javax.swing.*;

//Layouts the managers
import java.awt.*;

//This handles actions like button clicks
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//This is the input/output operations
import java.io.*;

//This reads and writes files
import java.nio.charset.StandardCharsets;

//This is for arraylists, dates and UUID
import java.util.*;

//This imports interfaces but it is normally used for clarity
import java.util.List;

//Regular expressions like matching and searching in strings
import java.util.regex.Matcher;
import java.util.regex.Pattern;


// This is the main class where all the methods and logic are written
public class FinalPOEQuickChat {

    //Registered user information 
    static String usernameRegistered;
    static String passwordRegistered;
    static String phoneRegistered;

    //The chat statics
    static int totalMessagesSent = 0;
    static int messageNumber = 0;

    //This is the date format for the timestamps
    static SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm");

    //This is where Data is stored from the messages and this manages and tracks the messages
    static List<String> messagesSent = new ArrayList<>();
    static List<String> messagesDisregarded = new ArrayList<>();
    static List<MessageEntry> messagesStored = new ArrayList<>();
    static List<String> recipientNumbers = new ArrayList<>();
    static List<String> messageHashes = new ArrayList<>();
    static List<String> messageIDs = new ArrayList<>();

    //This reads the JSON File
    static final File JSON_FILE = new File("Jsonnew.json");
    
    
    // ---------------------------------------------------
    //                       Main
    // ---------------------------------------------------
    public static void main(String[] args) {
        //This load the existing messages from the JSON
        readMessagesFromJSON();
        loadTestData(); 

        //This method shows a simple registration and login feature after this it then launches the GUI
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat Pro!"); //This is the welcome message
        registerUser();

        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Login successful. Entering Chat..."); //This displays when the login was succesfull then the user is able to enter the chat
            runMainMenu();
            // launch GUI main frame
            SwingUtilities.invokeLater(() -> {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            });
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting application."); //This is when the login fails, so this makes the application exit
            System.exit(0);
        }
    }

    //This method represents the UI style
    private static void setGlobalUIStyle(){
        //Larger buttons, modern font
        UIManager.put("Button.font", new Font("Segoe UI", Font.PLAIN, 14));
        UIManager.put("OptionPane.messageFont", new Font("Segoe UI", Font.PLAIN, 13));
    }

    //This method registers the users.
   public static void registerUser() {
        boolean valid = false;
        while (!valid) {
            usernameRegistered = JOptionPane.showInputDialog("Create a username (must contain _ and max 5 chars):");
            if (!(usernameRegistered != null && usernameRegistered.contains("_") && usernameRegistered.length() <= 5)) {
                JOptionPane.showMessageDialog(null, "Invalid username.");
                continue;
            }
           //Validates password
            passwordRegistered = JOptionPane.showInputDialog("Create password (8+ chars, 1 capital, 1 number, 1 special):");
            if (!passwordRegistered.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
                JOptionPane.showMessageDialog(null, "Invalid password.");
                continue;
            }
            phoneRegistered = JOptionPane.showInputDialog("Enter phone number (+27xxxxxxxxx):");
            if (!(phoneRegistered != null && phoneRegistered.matches("^\\+27[6-8]\\d{8}$"))) {
                JOptionPane.showMessageDialog(null, "Invalid phone number.");
                continue;
            }
            JOptionPane.showMessageDialog(null, "Registration successful!");
            valid = true;
    }
}
    //This method loads the test data 
    public static void loadTestData() {

    // Message 1 - Sent
    messagesSent.add("Did you get the cake?");
    recipientNumbers.add("+278345557896");
    String id1 = generateMessageID();
    messageIDs.add(id1);
    messageHashes.add(generateMessageHash(id1, ++messageNumber, "Did you get the cake?"));

    // Message 2 - Stored
    String id2 = generateMessageID();
    messagesStored.add(new MessageEntry(id2, generateMessageHash(id2, ++messageNumber, 
        "Where are you? You are late! I have asked you to be on time."),
        "+27838884567",
        "Where are you? You are late! I have asked you to be on time.",
        dateFormat.format(new Date()))
    );

    // Message 3 - Disregard
    messagesDisregarded.add("Yohoooo, I am at your gate.");

    // Message 4 - Sent
    messagesSent.add("It is dinner time!");
    recipientNumbers.add("08388884567");
    String id4 = generateMessageID();
    messageIDs.add(id4);
    messageHashes.add(generateMessageHash(id4, ++messageNumber, "It is dinner time!"));

    // Message 5 - Stored
    String id5 = generateMessageID();
    messagesStored.add(new MessageEntry(id5, generateMessageHash(id5, ++messageNumber,
        "Ok, I am leaving without you."),
        "+27838884567",
        "Ok, I am leaving without you.",
        dateFormat.format(new Date()))
    );

    writeAllMessagesToJSON(); // Saves stored messages to the JSON file
}

    //This is where the login feature takes place
    public static boolean loginUser() {
        String user = JOptionPane.showInputDialog("Enter your username:"); //This happens when you need to enter your username
        String pass = JOptionPane.showInputDialog("Enter your password:"); //The user has to enter the password
        return user != null && pass != null && user.equals(usernameRegistered) && pass.equals(passwordRegistered); //The user will be registered if the username and password is correct
    }

    // --------------------------------------------------
    //                    GUI Frame 
    // --------------------------------------------------
    static class GradientPanel extends JPanel {
        Color topColor = new Color(0xB3E5FC);     // light
        Color bottomColor = new Color(0x0288D1);  // darker
        // This is a vertical gradient from topColor to bottomColor

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            int w = getWidth(), h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, topColor, 0, h, bottomColor);
            g2.setPaint(gp);
            g2.fillRect(0, 0, w, h);
            g2.dispose();
        }
    }
//This method creates a mini frame 
    static class MainFrame extends JFrame {
        MainFrame() {
            setTitle("QuickChat Pro - Main Menu");
            setSize(480, 360);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setResizable(false);

            GradientPanel bg = new GradientPanel();
            bg.setLayout(new GridBagLayout());
            add(bg);

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(12, 20, 12, 20);
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.gridx = 0;

            JButton btnSend = new JButton("Send Messages");
            btnSend.setFont(new Font("Segoe UI", Font.BOLD, 16));
            btnSend.addActionListener(e -> sendMessagesDialog());

            JButton btnManager = new JButton("Message Manager");
            btnManager.setFont(new Font("Segoe UI", Font.BOLD, 16));
            btnManager.addActionListener(e -> openMessageManager());

            JButton btnExit = new JButton("Exit");
            btnExit.setFont(new Font("Segoe UI", Font.BOLD, 16));
            btnExit.addActionListener(e -> {
                JOptionPane.showMessageDialog(this, "Goodbye!");
                System.exit(0);
            });

            gbc.gridy = 0;
            bg.add(btnSend, gbc);
            gbc.gridy = 1;
            bg.add(btnManager, gbc);
            gbc.gridy = 2;
            bg.add(btnExit, gbc);
        }
    }

    // Main menu with message system + message manager options
    public static void runMainMenu() {
        boolean keepRunning = true;
        while (keepRunning) {
            String[] options = {"Send Messages", "Message Manager", "Exit" }; //These options will display on what you choose to do
            int choice = JOptionPane.showOptionDialog(null, "Select an option:", "Main Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
            switch (choice) {
                case 0 -> sendMessages();
                case 1 -> messageManagerMenu();
                case 2, JOptionPane.CLOSED_OPTION -> {
                    keepRunning = false;
                    JOptionPane.showMessageDialog(null, "Goodbye!"); //This displays when the user is done with everything and they have exited the application
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }

    // Send messages interface (console/dialog version)
    public static void sendMessages() {
        String input = JOptionPane.showInputDialog("How many messages would you like to send?"); //This is an option that asks how many messages you want to send
        if (input == null) return;
        int numMessages;
        try {
            numMessages = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number.");
            return;
        }

        for (int i = 0; i < numMessages; i++) {
            messageNumber++;
            String messageID = generateMessageID();

            String recipient = JOptionPane.showInputDialog("Enter recipient number (+27xxxxxxxxx):");
            if (recipient == null || !recipient.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Invalid recipient number.");
                i--;
                continue;
            }

            String message = JOptionPane.showInputDialog("Enter message (max 250 characters):");
            if (message == null) {
                i--;
                continue;
            }
            if (message.length() > 250) {
                JOptionPane.showMessageDialog(null, "Message too long by " + (message.length() - 250) + " characters.");
                i--;
                continue;
            }

            String timestamp = dateFormat.format(new Date());
            String hash = generateMessageHash(messageID, messageNumber, message);

            String[] actions = {"Send", "Disregard", "Store"};
            int action = JOptionPane.showOptionDialog(null, "What do you want to do?", "Message Options",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, actions, actions[0]);

            switch (action) {
                case 0 -> { //Send
                    totalMessagesSent++;
                    // Add to sent message arrays
                    messagesSent.add(message + " (Sent: " + timestamp + ")");
                    recipientNumbers.add(recipient);
                    messageIDs.add(messageID);
                    messageHashes.add(hash);
                    displayMessageDetails(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully sent.");
                }
                case 1 -> {  //Disregard
                    messagesDisregarded.add(message);
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                }
                case 2 -> { //Store in JSON
                    MessageEntry entry = new MessageEntry(messageID, hash, recipient, message, timestamp);
                    messagesStored.add(entry); // <-- add(me) implemented here
                    writeAllMessagesToJSON(); // persist all stored messages to a valid JSON array
                    JOptionPane.showMessageDialog(null, "Message stored.");
                }
                default -> {
                    JOptionPane.showMessageDialog(null, "No action taken.");
                    i--;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Total messages sent (session): " + totalMessagesSent);
    }

    // A GUI-friendly send dialog 
    public static void sendMessagesDialog() {
        String recipient = JOptionPane.showInputDialog(null, "Enter recipient number (+27xxxxxxxxx):");
        if (recipient == null || !recipient.matches("^\\+27\\d{9}$")) {
            JOptionPane.showMessageDialog(null, "Invalid recipient number.");
            return;
        }
        String message = JOptionPane.showInputDialog(null, "Enter message (max 250 characters):");
        if (message == null) return;
        if (message.length() > 250) {
            JOptionPane.showMessageDialog(null, "Message too long.");
            return;
        }

        messageNumber++;
        String messageID = generateMessageID();
        String timestamp = dateFormat.format(new Date());
        String hash = generateMessageHash(messageID, messageNumber, message);

        String[] actions = {"Send", "Disregard", "Store"};
        int action = JOptionPane.showOptionDialog(null, "What do you want to do with this message?", "Message Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, actions, actions[0]);

        switch (action) {
            case 0 -> {
                totalMessagesSent++;
                messagesSent.add(message + " (Sent: " + timestamp + ")");
                recipientNumbers.add(recipient);
                messageIDs.add(messageID);
                messageHashes.add(hash);
                displayMessageDetails(messageID, hash, recipient, message);
                JOptionPane.showMessageDialog(null, "Message successfully sent.");
            }
            case 1 -> {
                messagesDisregarded.add(message);
                JOptionPane.showMessageDialog(null, "Message disregarded.");
            }
            case 2 -> {
                MessageEntry entry = new MessageEntry(messageID, hash, recipient, message, timestamp);
                messagesStored.add(entry);
                writeAllMessagesToJSON();
                JOptionPane.showMessageDialog(null, "Message stored.");
            }
            default -> JOptionPane.showMessageDialog(null, "No action taken.");
        }
    }

    // Opens a simple message manager dialog
    public static void openMessageManager() {
        messageManagerMenu();
    }

    //This is the message manager operations that represents the dialogs.
    public static void messageManagerMenu() {
        boolean running = true;

        while (running) {
            String[] options = {
                "Display all sent messages", //This displays all of the messages that have been sent
                "Display longest sent message", //This displays and shows the longest message that has been sent
                "Search by Message ID", //This feature displays when you want to search a spcific user by their ID
                "Search messages by recipient", //This feature displays when you want to search a spcific user by their recipient
                "Delete message by hash", //This feature works when you want to delete a specific message using a hash
                "Show full report", //This feature displays the full report
                "Back to Main Menu" //This feature is used when you want to go back to the main menu/when you are done or want to start all over again.
            };
            int choice = JOptionPane.showOptionDialog(null, "Message Manager Options:", "Message Manager",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0 -> displaySendersAndRecipients();
                case 1 -> displayLongestMessage();
                case 2 -> { String id = JOptionPane.showInputDialog("Enter Message ID:"); if (id != null) searchByMessageID(id);}
                case 3 -> { String r = JOptionPane.showInputDialog("Enter Recipient Number:"); if (r != null) searchByRecipient(r);}
                case 4 -> { String h = JOptionPane.showInputDialog("Enter Message Hash:"); if (h != null) deleteByMessageHash(h);}
                case 5 -> displayReport();
                case 6, JOptionPane.CLOSED_OPTION -> running = false;
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }

    // === Message Manager methods ===
    public static void displaySendersAndRecipients() {
        if (messagesSent.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messagesSent.size(); i++) {
            sb.append("Recipient: ").append(recipientNumbers.get(i)).append("\n");
            sb.append("Message: ").append(messagesSent.get(i)).append("\n");
            sb.append("Hash: ").append(messageHashes.get(i)).append("\n");
            sb.append("ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("---------------------------\n");
        }
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(520, 380));
        JOptionPane.showMessageDialog(null, scroll, "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }
    
    //We use this method to display the longest message
    public static void displayLongestMessage() {
        if (messagesSent.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }
        String longest = "";
        for (String msg : messagesSent) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest Sent Message:\n" + longest);
    }
    
    //The user will be able to search a certain messages by using IDs
    public static void searchByMessageID(String id) {
        //Messages sent need to be checeked first
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                String msgDetails = "Recipient: " + recipientNumbers.get(i) + "\nMessage: " + messagesSent.get(i);
                JOptionPane.showMessageDialog(null, msgDetails, "Search Result", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }

        // Check stored messages
        for (MessageEntry me: messagesStored) {
            if (me.messageID.equals(id)) {
                JOptionPane.showMessageDialog(null, me.toDisplayString(), "Search Result", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    //  //The user will be able to search a certain messages by using recipient
    public static void searchByRecipient(String recipientNumber) {
        StringBuilder sb = new StringBuilder("Messages to " + recipientNumber + ":\n\n");
        boolean found = false;

        for (int i = 0; i < recipientNumbers.size(); i++) {
            if (recipientNumbers.get(i).equals(recipientNumber)) {
                sb.append(messagesSent.get(i)).append("\n");
                found = true;
            }
        }
        for (MessageEntry stored : messagesStored) {
            if (stored.recipient.equals(recipientNumber)) {
                sb.append(stored.toDisplayString()).append("\n");
                found = true;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipientNumber);
        } else {
            JTextArea area = new JTextArea(sb.toString());
            area.setEditable(false);
            area.setLineWrap(true);
            area.setWrapStyleWord(true);
            JScrollPane scroll = new JScrollPane(area);
            scroll.setPreferredSize(new Dimension(480, 320));
            JOptionPane.showMessageDialog(null, scroll, "Messages by Recipient", JOptionPane.INFORMATION_MESSAGE);
        }
    }
  //The user will be able to delete certain messages by using a Hash
    public static void deleteByMessageHash(String hash) {
        // check sent messages
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equalsIgnoreCase(hash)) {
                int confirm = JOptionPane.showConfirmDialog(null,
                         "Are sure you want to delete this message?\n\n" + messagesSent.get(i),
                          "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    messagesSent.remove(i);
                    recipientNumbers.remove(i);
                    messageIDs.remove(i);
                    messageHashes.remove(i);
                    JOptionPane.showMessageDialog(null, "Message Deleted");
                } else {
                    JOptionPane.showMessageDialog(null, "Delete cancelled.");
                }
                return;
            }
        }
        // check stored messages
        for (int i = 0; i < messagesStored.size(); i++) {
            if (messagesStored.get(i).messageHash.equalsIgnoreCase(hash)) {
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Are you sure you want to delete this stored message?\n\n" + messagesStored.get(i).toDisplayString(),
                        "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    messagesStored.remove(i);
                    writeAllMessagesToJSON(); // persist change
                    JOptionPane.showMessageDialog(null, "Stored Message Deleted");
                } else {
                    JOptionPane.showMessageDialog(null, "Delete cancelled.");
                }
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message hash was not found.");
    }

      //This method display the report of the messages
    public static void displayReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("===== MESSAGE SUMMARY REPORT =====\n");
        sb.append("Total Sent Messages: ").append(messagesSent.size()).append("\n");
        sb.append("Stored Messages: ").append(messagesStored.size()).append("\n");
        sb.append("Total Disregarded Messages ").append(messagesDisregarded.size()).append("\n\n");

        if (!messagesStored.isEmpty()) {
            sb.append("\n-------- STORED MESSAGES (JSON) ------\n");
            for (MessageEntry me : messagesStored) {
                sb.append(me.toDisplayString()).append("\n-----------------------------\n");
            }
        }

        if (messagesSent.isEmpty()) {
            sb.append("No sent messages to display.");
        } else {
            sb.append("-------- SENT MESSAGE REPORT ------\n");
            for (int i = 0; i < messagesSent.size(); i++) {
                sb.append("Message ID: ").append(messageIDs.get(i)).append("\n");
                sb.append("Message Hash: ").append(messageHashes.get(i)).append("\n");
                sb.append("Recipient: ").append(recipientNumbers.get(i)).append("\n");
                sb.append("Message: ").append(messagesSent.get(i)).append("\n");
                sb.append("-----------------------------\n");
            }
        }

        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(520, 380));
        JOptionPane.showMessageDialog(null, scroll, "Message Report", JOptionPane.INFORMATION_MESSAGE);
    }

    // This generates a unique message ID and also returns a unique string identifier and lastly throws RunTimeException if unable to generate a unique ID
    public static String generateMessageID () {
         return UUID.randomUUID().toString();
    }
  //The user will be able to a generate a message hash 
    public static String generateMessageHash(String id, int num, String msg) {
       String cleaned = msg.trim().replaceAll("\\s+", " ");
        String[] words = cleaned.split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : "";
        String base = id.length() >= 8 ? id.substring(0, 8) : id;
        return (base + ":" + num + ":" + first + "" + last).toUpperCase().replaceAll("[^A-Z0-9:]", "");
    }

    //This displays the message details 
    public static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null,
                "Message ID: " + id + "\nHash: " + hash + "\nRecipient: " + recipient + "\nMessage: " + message);
    }

    // ------------------------------------------
    // This JSON reads/writes (valid JSON array)
    // ------------------------------------------
    static class MessageEntry {
        String messageID;
        String messageHash;
        String recipient;
        String message;
        String timestamp;

        MessageEntry(String messageID, String messageHash, String recipient, String message, String timestamp) {
            this.messageID = messageID;
            this.messageHash = messageHash;
            this.recipient = recipient;
            this.message = message;
            this.timestamp = timestamp;
        }

        String toJSON() {
            return "{\n" +
                    "  \"MessageID\": \"" + escapeJson(messageID) + "\",\n" +
                    "  \"MessageHash\": \"" + escapeJson(messageHash) + "\",\n" +
                    "  \"Recipient\": \"" + escapeJson(recipient) + "\",\n" +
                    "  \"Message\": \"" + escapeJson(message) + "\",\n" +
                    "  \"Timestamp\": \"" + escapeJson(timestamp) + "\"\n" +
                    "}";
        }

        String toDisplayString() {
            return "Message ID: " + messageID + "\nHash: " + messageHash + "\nRecipient: " + recipient + "\nTimestamp: " + timestamp + "\nMessage: " + message;
        }

        static String escapeJson(String s) {
            if (s == null) return "";
            return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
        }
    }
  //The user will be able to write all the messages on JSON
    private static void writeAllMessagesToJSON() {
        // Writes the entire storedMessages list to a valid JSON array file
        try (OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(JSON_FILE, false), StandardCharsets.UTF_8)) {
            writer.write("[\n");
            for (int i = 0; i < messagesStored.size(); i++) {
                writer.write(messagesStored.get(i).toJSON());
                if (i < messagesStored.size() - 1) writer.write(",\n");
                else writer.write("\n");
            }
            writer.write("]\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing JSON file: " + e.getMessage());
        }
    }
 //The user will be able to read all the messages on JSON
    private static void readMessagesFromJSON() {
        if (!JSON_FILE.exists()) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(JSON_FILE), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append("\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading JSON file: " + e.getMessage());
            return;
        }

        String content = sb.toString().trim();
        if (content.isEmpty()) return;
        // Expecting a JSON array. Use regex to extract object blocks.
        Pattern objPattern = Pattern.compile("\\{(.*?)\\}", Pattern.DOTALL);
        Matcher matcher = objPattern.matcher(content);

        while (matcher.find()) {
            String obj = matcher.group(1);
            String id = extractJsonString(obj, "MessageID");
            String hash = extractJsonString(obj, "MessageHash");
            String recipient = extractJsonString(obj, "Recipient");
            String message = extractJsonString(obj, "Message");
            String timestamp = extractJsonString(obj, "Timestamp");
            if (id != null && !id.isEmpty()) {
                MessageEntry me = new MessageEntry(id, hash != null ? hash : "", recipient != null ? recipient : "", message != null ? message : "", timestamp != null ? timestamp : "");
                messagesStored.add(me);
            }
        }
    }
 //The user will be able to extract all the strings on JSON
    private static String extractJsonString(String obj, String key) {
        Pattern p = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"(.*?)\"", Pattern.DOTALL);
        Matcher m = p.matcher(obj);
        if (m.find()) {
            String raw = m.group(1);
            // Unescape common sequences
            return raw.replace("\\n", "\n").replace("\\r", "\r").replace("\\\"", "\"").replace("\\\\", "\\");
        }
        return null;
        
    }
}